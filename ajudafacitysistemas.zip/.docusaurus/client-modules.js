export default [
  require("C:\\Projetos\\Node\\docusaurus\\ajudafacitysistemas\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Projetos\\Node\\docusaurus\\ajudafacitysistemas\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Projetos\\Node\\docusaurus\\ajudafacitysistemas\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Projetos\\Node\\docusaurus\\ajudafacitysistemas\\src\\css\\custom.css"),
];
