import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/ajudafacitysistemas/__docusaurus/debug',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug', 'cdd'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/__docusaurus/debug/config',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug/config', 'f32'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/__docusaurus/debug/content',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug/content', '237'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/__docusaurus/debug/globalData',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug/globalData', 'b57'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/__docusaurus/debug/metadata',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug/metadata', 'ff2'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/__docusaurus/debug/registry',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug/registry', '07d'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/__docusaurus/debug/routes',
    component: ComponentCreator('/ajudafacitysistemas/__docusaurus/debug/routes', '134'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog',
    component: ComponentCreator('/ajudafacitysistemas/blog', '093'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/archive',
    component: ComponentCreator('/ajudafacitysistemas/blog/archive', 'e0d'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/authors',
    component: ComponentCreator('/ajudafacitysistemas/blog/authors', 'd25'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/ajudafacitysistemas/blog/authors/all-sebastien-lorber-articles', 'eb4'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/authors/yangshun',
    component: ComponentCreator('/ajudafacitysistemas/blog/authors/yangshun', 'aed'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/first-blog-post',
    component: ComponentCreator('/ajudafacitysistemas/blog/first-blog-post', 'b72'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/long-blog-post',
    component: ComponentCreator('/ajudafacitysistemas/blog/long-blog-post', '976'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/mdx-blog-post',
    component: ComponentCreator('/ajudafacitysistemas/blog/mdx-blog-post', 'f81'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/tags',
    component: ComponentCreator('/ajudafacitysistemas/blog/tags', '3fa'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/tags/docusaurus',
    component: ComponentCreator('/ajudafacitysistemas/blog/tags/docusaurus', '1b1'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/tags/facebook',
    component: ComponentCreator('/ajudafacitysistemas/blog/tags/facebook', '9b9'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/tags/hello',
    component: ComponentCreator('/ajudafacitysistemas/blog/tags/hello', 'b9e'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/tags/hola',
    component: ComponentCreator('/ajudafacitysistemas/blog/tags/hola', 'c0c'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/blog/welcome',
    component: ComponentCreator('/ajudafacitysistemas/blog/welcome', 'af8'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/markdown-page',
    component: ComponentCreator('/ajudafacitysistemas/markdown-page', '7bc'),
    exact: true
  },
  {
    path: '/ajudafacitysistemas/docs',
    component: ComponentCreator('/ajudafacitysistemas/docs', '949'),
    routes: [
      {
        path: '/ajudafacitysistemas/docs',
        component: ComponentCreator('/ajudafacitysistemas/docs', '2ee'),
        routes: [
          {
            path: '/ajudafacitysistemas/docs',
            component: ComponentCreator('/ajudafacitysistemas/docs', 'c0f'),
            routes: [
              {
                path: '/ajudafacitysistemas/docs/admin',
                component: ComponentCreator('/ajudafacitysistemas/docs/admin', '79d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/category/teste',
                component: ComponentCreator('/ajudafacitysistemas/docs/category/teste', 'fda'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/category/tutorial---basics',
                component: ComponentCreator('/ajudafacitysistemas/docs/category/tutorial---basics', 'c0b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/category/tutorial---extras',
                component: ComponentCreator('/ajudafacitysistemas/docs/category/tutorial---extras', '373'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/intro',
                component: ComponentCreator('/ajudafacitysistemas/docs/intro', '02d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/Teste/Parabéns',
                component: ComponentCreator('/ajudafacitysistemas/docs/Teste/Parabéns', 'b1c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-basics/congratulations',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-basics/congratulations', '0e6'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-basics/create-a-blog-post',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-basics/create-a-blog-post', '69c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-basics/create-a-document',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-basics/create-a-document', '683'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-basics/create-a-page',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-basics/create-a-page', '4a5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-basics/deploy-your-site',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-basics/deploy-your-site', '41f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-basics/markdown-features',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-basics/markdown-features', 'ea3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-extras/manage-docs-versions',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-extras/manage-docs-versions', '418'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/ajudafacitysistemas/docs/tutorial-extras/translate-your-site',
                component: ComponentCreator('/ajudafacitysistemas/docs/tutorial-extras/translate-your-site', '5e4'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/ajudafacitysistemas/',
    component: ComponentCreator('/ajudafacitysistemas/', '54d'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
