---
title: Admin
slug: /admin
---

<meta http-equiv="refresh" content="0; url=/ajudafacitysistemas/admin/index.html" />
